const Discord = require("discord.js");

/**
 * @type {import("../../typings.d").Command}
 */
module.exports = async (client, interaction, args) => {
  fetch(`https://some-random-api.com/facts/cat`)
    .then((res) => res.json())
    .catch({})
    .then(async (json) => {
      client.embed(
        {
          title: `💡・Dato aleatorio sobre gatos`,
          desc: json.fact,
          type: "editreply",
        },
        interaction,
      );
    })
    .catch({});
};
