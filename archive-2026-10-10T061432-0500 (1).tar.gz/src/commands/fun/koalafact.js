const Discord = require("discord.js");
const fetch = require("node-fetch");

/**
 * @type {import("../../typings.d").Command}
 */
module.exports = async (client, interaction, args) => {
  fetch(`https://some-random-api.com/facts/koala`)
    .then((res) => res.json())
    .catch({})
    .then(async (json) => {
      client.embed(
        {
          title: `💡・Dato aleatorio sobre koalas`,
          desc: json.fact,
          type: "editreply",
        },
        interaction,
      );
    })
    .catch({});
};
