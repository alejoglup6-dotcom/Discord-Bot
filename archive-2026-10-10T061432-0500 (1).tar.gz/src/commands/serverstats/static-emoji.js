const Discord = require("discord.js");

const Schema = require("../../database/models/stats");

/**
 * @type {import("../../typings.d").Command}
 */
module.exports = async (client, interaction, args) => {
  let Emojis = "";
  let EmojiCount = 0;
  let Animated = 0;
  let OverallEmojis = 0;

  function Emoji(id) {
    return client.emojis.cache.get(id).toString();
  }

  interaction.guild.emojis.cache.forEach((emoji) => {
    OverallEmojis++;
    if (emoji.animated) {
      Animated++;
    } else {
      EmojiCount++;
    }
  });

  var channelName = await client.getTemplate(interaction.guild);
  channelName = channelName.replace(`{emoji}`, "😀");
  channelName = channelName.replace(
    `{name}`,
    `Emojis estáticos: ${EmojiCount || "0"}`,
  );

  await interaction.guild.channels
    .create({
      name: channelName,
      type: Discord.ChannelType.GuildVoice,
      permissionOverwrites: [
        {
          deny: [Discord.PermissionsBitField.Flags.Connect],
          id: interaction.guild.id,
        },
      ],
    })
    .then(async (channel) => {
      Schema.findOne({ Guild: interaction.guild.id }).then(async (data) => {
        if (data) {
          data.StaticEmojis = channel.id;
          data.save();
        } else {
          new Schema({
            Guild: interaction.guild.id,
            StaticEmojis: channel.id,
          }).save();
        }
      });

      client.succNormal(
        {
          text: `¡Se creó el contador de emojis estáticos!`,
          fields: [
            {
              name: `📘┆Canal`,
              value: `${channel}`,
            },
          ],
          type: "editreply",
        },
        interaction,
      );
    });
};
