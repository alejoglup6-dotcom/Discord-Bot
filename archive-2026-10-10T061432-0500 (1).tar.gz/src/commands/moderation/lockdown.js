const Discord = require("discord.js");

/**
 * @type {import("../../typings.d").Command}
 */
module.exports = async (client, interaction, args) => {
  const perms = await client.checkPerms(
    {
      flags: [Discord.PermissionsBitField.Flags.ManageChannels],
      perms: [Discord.PermissionsBitField.Flags.ManageChannels],
    },
    interaction,
  );

  if (perms == false) return;

  interaction.guild.channels.cache.forEach((ch) => {
    if (ch.type == Discord.ChannelType.GuildText) {
      ch.permissionOverwrites.edit(interaction.guild.id, {
        SendMessages: false,
      });
    }
  });

  client.succNormal(
    {
      text: "Canales bloqueados correctamente",
      type: "editreply",
    },
    interaction,
  );
};
