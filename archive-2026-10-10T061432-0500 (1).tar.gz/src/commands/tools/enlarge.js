const Discord = require("discord.js");

/**
 * @type {import("../../typings.d").Command}
 */
module.exports = async (client, interaction, args) => {
  const emoji = interaction.options.getString("emoji");
  const parsedEmoji = Discord.parseEmoji(emoji);

  if (parsedEmoji) {
    const ex = parsedEmoji.animated ? ".gif" : ".png";
    const url = `https://cdn.discordapp.com/emojis/${parsedEmoji.id + ex}`;

    return client.embed(
      {
        image: url,
        type: "editreply",
      },
      interaction,
    );
  } else {
    client.errNormal(
      { error: "¡Indica un emoji válido!", type: "editreply" },
      interaction,
    );
  }
};
