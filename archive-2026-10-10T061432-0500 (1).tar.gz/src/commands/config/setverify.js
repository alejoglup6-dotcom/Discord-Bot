const Discord = require("discord.js");

const Schema = require("../../database/models/verify");

/**
 * @type {import("../../typings.d").Command}
 */
module.exports = async (client, interaction, args) => {
  const perms = await client.checkUserPerms(
    {
      flags: [Discord.PermissionsBitField.Flags.ManageMessages],
      perms: [Discord.PermissionsBitField.Flags.ManageMessages],
    },
    interaction,
  );

  if (perms == false) return;

  const boolean = interaction.options.getBoolean("enable");
  const channel = interaction.options.getChannel("channel");
  const role = interaction.options.getRole("role");

  if (boolean == true) {
    const data = await Schema.findOne({ Guild: interaction.guild.id });
    if (data) {
      data.Channel = channel.id;
      data.Role = role.id;
      data.save();
    } else {
      new Schema({
        Guild: interaction.guild.id,
        Channel: channel.id,
        Role: role.id,
      }).save();
    }

    client.succNormal(
      {
        text: `El panel de verificación se creó correctamente`,
        fields: [
          {
            name: `📘┆Canal`,
            value: `${channel} (${channel.name})`,
            inline: true,
          },
          {
            name: `📛┆Rol`,
            value: `${role} (${role.name})`,
            inline: true,
          },
        ],
        type: "editreply",
      },
      interaction,
    );

    // Panel nuevo: la verificación es vinculando la cuenta del juego en la web (src/assets/utils/verification.js)
    await channel.send(require("../../assets/utils/verification").panel(interaction.guild)).catch(() => {});
  }
};
